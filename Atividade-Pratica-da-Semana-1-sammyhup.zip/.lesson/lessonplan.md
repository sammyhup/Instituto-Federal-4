# Rubrica de correção
  ![Grade](assets/F1-M4-Sem01-Praticas-Grade.png)